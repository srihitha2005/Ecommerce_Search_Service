package com.example.SearchServiceApplication.document;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Entity
@Table(name = "product_search_view")
public class ProductSearchDocument {

    @Id
    @Column(name = "stock_id")
    private Long stockId;

    @Column(name = "product_id")
    private Long productId;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "description")
    private String description;

    @Column(name = "category_id")
    private Long categoryId;

    @Column(name = "merchant_id")
    private Long merchantId;

    @Column(name = "store_name")
    private String storeName;

    @Column(name = "price")
    private BigDecimal price;

    @Column(name = "current_stock")
    private Integer currentStock;

    @Column(name = "merchant_count")
    private Integer merchantCount;
}
