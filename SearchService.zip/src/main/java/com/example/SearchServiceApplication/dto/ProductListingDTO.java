package com.example.SearchServiceApplication.dto;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class ProductListingDTO {

    private Long stockId;
    private Long productId;

    private String productName;
    private String description;

    private String storeName;
    private BigDecimal price;

    private Integer merchantCount;
}
