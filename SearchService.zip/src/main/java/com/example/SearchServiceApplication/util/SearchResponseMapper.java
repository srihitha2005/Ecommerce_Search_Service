package com.example.SearchServiceApplication.util;

import com.example.SearchServiceApplication.document.ProductSearchDocument;
import com.example.SearchServiceApplication.dto.ProductListingDTO;

public class SearchResponseMapper {

    private SearchResponseMapper() {}

    public static ProductListingDTO toDTO(ProductSearchDocument doc) {

        ProductListingDTO dto = new ProductListingDTO();

        dto.setStockId(doc.getStockId());
        dto.setProductId(doc.getProductId());
        dto.setProductName(doc.getProductName());
        dto.setDescription(doc.getDescription());
        dto.setStoreName(doc.getStoreName());
        dto.setPrice(doc.getPrice());
        dto.setMerchantCount(doc.getMerchantCount());

        return dto;
    }
}
