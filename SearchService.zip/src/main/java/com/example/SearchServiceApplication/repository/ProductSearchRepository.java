package com.example.SearchServiceApplication.repository;

import com.example.SearchServiceApplication.document.ProductSearchDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProductSearchRepository extends JpaRepository<ProductSearchDocument, Long> {

    @Query(value = """
        SELECT *, 
               ts_rank(search_vector, websearch_to_tsquery('english', :keyword)) AS rank
        FROM product_search_view
        WHERE current_stock > 0
          AND (
            search_vector @@ websearch_to_tsquery('english', :keyword) -- Fast Word Match
            OR product_name % :keyword                                 -- Typo Fallback
          )
        ORDER BY rank DESC, similarity(product_name, :keyword) DESC
        LIMIT 25
        """, nativeQuery = true)
    List<ProductSearchDocument> hybridSearch(@Param("keyword") String keyword);
}