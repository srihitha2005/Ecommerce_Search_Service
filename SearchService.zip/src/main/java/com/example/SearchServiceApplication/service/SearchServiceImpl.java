package com.example.SearchServiceApplication.service;

import com.example.SearchServiceApplication.dto.SearchResponseDTO;
import com.example.SearchServiceApplication.repository.ProductSearchRepository;
import com.example.SearchServiceApplication.util.SearchResponseMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
@RequiredArgsConstructor
public class SearchServiceImpl implements SearchService {

    private final ProductSearchRepository repository;

    @Override
    public SearchResponseDTO search(String keyword) {

        SearchResponseDTO response = new SearchResponseDTO();
        response.setQuery(keyword);

        if (keyword == null || keyword.trim().isEmpty()) {
            response.setTotalResults(0);
            response.setMessage("Please provide a search keyword");
            response.setResults(Collections.emptyList());
            return response;
        }

        var docs = repository.hybridSearch(keyword);

        response.setTotalResults(docs.size());
        response.setMessage(docs.isEmpty()
                ? "No products found"
                : "Search results found");

        response.setResults(
                docs.stream()
                        .map(SearchResponseMapper::toDTO)
                        .toList()
        );

        return response;
    }
}
