package com.example.SearchServiceApplication.service;

import com.example.SearchServiceApplication.dto.SearchResponseDTO;

public interface SearchService {

    SearchResponseDTO search(String keyword);
}
